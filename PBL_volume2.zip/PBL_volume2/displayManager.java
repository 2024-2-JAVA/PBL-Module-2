import BMICalculator.BMICalculatorExample;
import C_F.C_F_CalculatorExample;
import calc.CalculatorExample;
import discount.DisCalculatorExample;
import formation.FormCalculatorExample;
import meter_inch.Meter_inch_CalculatorExample;

public class displayManager {
    public static Meter_inch_CalculatorExample meter_inch_calculator = new Meter_inch_CalculatorExample();
    public static C_F_CalculatorExample c_f_calculator = new C_F_CalculatorExample();
    public static FormCalculatorExample formCalculator = new FormCalculatorExample();
    public static DisCalculatorExample disCalculator = new DisCalculatorExample();
    public static CalculatorExample calculator = new CalculatorExample();
    public static BMICalculatorExample BMI = new BMICalculatorExample();
}
